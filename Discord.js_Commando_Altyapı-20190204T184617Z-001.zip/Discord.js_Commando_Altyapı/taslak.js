const Discord = require('discord.js');
const db = require('quick.db');

exports.run = async function(client, message, args, qu) {

    
    
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [""],
  kategori: "",
  permLevel: 0
};

exports.help = {
  name: '',
  description: '',
  usage: ''
};